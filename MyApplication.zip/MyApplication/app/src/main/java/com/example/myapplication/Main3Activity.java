package com.example.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;

public class Main3Activity extends AppCompatActivity {
    // the message to be disaplyed when this button is clicked is linked here

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        String savedExtra = getIntent().getStringExtra("No");
        TextView mytext = (TextView)findViewById(R.id.textView2);
        mytext.setText(savedExtra);
    }
}
