package com.example.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;

public class Main2Activity extends AppCompatActivity {
    // the message to be disaplyed when this button is clicked is linked here
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        String savedExtra = getIntent().getStringExtra("Yes");
        TextView mytext = (TextView)findViewById(R.id.textView);
        mytext.setText(savedExtra);
    }
}
