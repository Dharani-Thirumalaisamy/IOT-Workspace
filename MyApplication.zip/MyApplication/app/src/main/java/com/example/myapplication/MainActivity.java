// importing the necessary packages

package com.example.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.ImageView;
import android.widget.Toast;
import java.io.InputStream;

// creating a class MainActivity that will be able to run on phones
public class MainActivity extends AppCompatActivity {
    // this method will have access to the layout of the first page of the application
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // object that will call the imageview section from the activity layout and the url which is a static url
        // for GCP storage bucket
        new DownloadImageFromInternet((ImageView) findViewById(R.id.imageView))
                .execute("https://storage.googleapis.com/iot-project/Test%20Image");
    }
    // this class will download the image from the url
    private class DownloadImageFromInternet extends AsyncTask<String, Void, Bitmap> {
        ImageView imageView;
        // text to be printed in case the image takes time to load
        public DownloadImageFromInternet(ImageView imageView) {
            this.imageView = imageView;
            Toast.makeText(getApplicationContext(), "Please wait, it may take a few minute...", Toast.LENGTH_SHORT).show();
        }
        // decoding the url
        protected Bitmap doInBackground(String... urls) {
            String imageURL = urls[0];
            Bitmap bimage = null;
            try {
                InputStream in = new java.net.URL(imageURL).openStream();
                bimage = BitmapFactory.decodeStream(in);

            } catch (Exception e) {
                Log.e("Error Message", e.getMessage());
                e.printStackTrace();
            }
            return bimage;
        }

        protected void onPostExecute(Bitmap result) {
            imageView.setImageBitmap(result);
        }
    }
    // this method access the first button that is created in the page and displays the text Yes.
    // Access granted is the message that has to be displayed once Yes is clicked
    public void onButtonClick(View v){
        Intent intent  = new Intent(getBaseContext(), Main2Activity.class);
        intent.putExtra("Yes", "Access Granted");
        Log.d("STATE","Access Granted");
        startActivity(intent);
    }
    // this method access the first button that is created in the page and displays the text No.
    // Access denied is the message that has to be displayed once No is clicked
    public void onButtonClick2(View v){
        Intent intent  = new Intent(getBaseContext(), Main3Activity.class);
        intent.putExtra("No", "Access Denied");
        Log.d("STATE","Access Denied");

        startActivity(intent);
    }

}
