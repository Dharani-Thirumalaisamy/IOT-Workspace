import pandas as pd
import numpy as np
import os
import cv2

from sklearn.model_selection import train_test_split

from keras.models import Sequential
from keras.layers import Conv2D, MaxPool2D, BatchNormalization, Dense, Flatten, Dropout
from keras.callbacks import ModelCheckpoint
from keras.utils import np_utils
from keras.preprocessing.image import ImageDataGenerator

# preprocessing the dataset

path = '/home/dharani/Desktop/Dataset/Dataset.csv'
path_to_image = '/home/dharani/Desktop/Dataset/Training'
filepath = "model-dataAug-{epoch:02d}-{acc:.2f}-{val_acc:.2f}.hdf5"

df = pd.read_csv(path)

df = df.sample(frac=1).reset_index(drop=True)
x = df['Image']
y = df['Class']

imgArr = []
for i in range(len(x)):
    temp = cv2.imread(os.path.join(path_to_image, x[i]), 1)
    temp = np.resize(temp, (128, 128, 3))
    imgArr.append(temp)

imgArr = np.array(imgArr)
print(len(imgArr))
print(imgArr.shape)

(train_x, test_x) = train_test_split(imgArr, test_size=0.2)
(train_y, test_y) = train_test_split(y, test_size=0.2)
print(train_x.shape, train_y.shape)
print(test_x.shape, test_y.shape)

train_x = train_x.astype('float32')
test_x = test_x.astype('float32')

train_x /= 255.0
test_x /= 255.0

train_y = np_utils.to_categorical(train_y, 2)
test_y = np_utils.to_categorical(test_y, 2)

'''
datagen = ImageDataGenerator(
    featurewise_center=True,
    featurewise_std_normalization=True,
    # zca_whitening=True,
    rotation_range=20,
    width_shift_range=0.2,
    height_shift_range=0.2,
    horizontal_flip=True)
'''
# Building model

model = Sequential()

model.add(Conv2D(8, 3, input_shape=(128, 128, 3), activation='relu'))
model.add(BatchNormalization())
model.add(MaxPool2D(2, 2))

model.add(Conv2D(8, 3, activation='relu'))
model.add(BatchNormalization())
model.add(MaxPool2D(2, 2))

model.add(Conv2D(16, 3, activation='relu'))
model.add(BatchNormalization())
model.add(MaxPool2D(2, 2))

model.add(Conv2D(16, 3, activation='relu'))
model.add(BatchNormalization())
model.add(MaxPool2D(2, 2))

model.add(Flatten())
model.add(Dropout(0.3))
model.add(Dense(2, activation='softmax'))

model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
checkpoint = ModelCheckpoint(filepath, monitor='val_acc', save_best_only=True)

# datagen.fit(train_x)
# fits the model on batches with real-time data augmentation:
# model.fit_generator(datagen.flow(train_x, train_y, batch_size=8),
#                     steps_per_epoch=len(train_x) / 8, epochs=50, callbacks=[checkpoint],
#                     validation_data=(test_x, test_y))
model.fit(train_x, train_y, epochs=50, batch_size=8, validation_data=(test_x, test_y))
